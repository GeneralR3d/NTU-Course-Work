public abstract class Shape{
    public abstract double calArea();
    //public abstract double calVolume();
}